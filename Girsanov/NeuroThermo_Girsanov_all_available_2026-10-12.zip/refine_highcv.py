"""Nested-replicate precision check: 16 -> 64 for preselected high-CV cases."""
from pathlib import Path
import sys,json
import pandas as pd,numpy as np
from concurrent.futures import ProcessPoolExecutor,as_completed
BASE=Path(__file__).parent
sys.path.insert(0,str(BASE))
from endpoint_kl import process,SUPPORT,JMAX
out=BASE/'endpoint_precision64';out.mkdir(exist_ok=True)
orig=pd.read_csv(BASE/'endpoint_all264/all264_directional_KL.csv')
a=orig[(orig.protocol=='paired_q75')&(orig.noise_scale==1)]
chosen=sorted(set(a.nlargest(12,'MC_CV').scenario_id).union({0,87,176,228,263}))
d=pd.read_csv(SUPPORT);d['J_q75']=d.rheobase_J+0.75*(d.cell_id.map(JMAX)-d.rheobase_J)
wt=d[d.cell_id.str.startswith('WT_')];sc=d[d.cell_id.str.startswith('SCA3_')]
tasks=[]
for wc in sorted(wt.cell_id.unique()):
 for sca in sorted(sc.cell_id.unique()):
  for _,w in wt[wt.cell_id==wc].iterrows():
   for _,s in sc[sc.cell_id==sca].iterrows():tasks.append((len(tasks),w.to_dict(),s.to_dict()))
assert len(tasks)==264
rows=[]
with ProcessPoolExecutor(max_workers=4) as pool:
 fs=[pool.submit(process,tasks[sid],64) for sid in chosen]
 for f in as_completed(fs):rows+=f.result()
r=pd.DataFrame(rows);r.to_csv(out/'n64.csv',index=False)
ref=orig[orig.scenario_id.isin(chosen)]
m=r.merge(ref,on=['scenario_id','protocol','noise_scale','reference'],suffixes=('_64','_16'),validate='one_to_one')
m['relative_change']=abs(m.KL_path_64-m.KL_path_16)/m.KL_path_64
m['Fz_delta']=abs(m.F_z_64-m.F_z_16)
m.to_csv(out/'nested16_64_comparison.csv',index=False)
part=m[(m.protocol=='paired_q75')&(m.noise_scale==1)]
summary=dict(n_highcv_cases=len(chosen), n_directional_paired_rows=len(part),
  paired_median_abs_relative_KL_change=float(part.relative_change.median()),
  paired_q90_abs_relative_KL_change=float(part.relative_change.quantile(.9)),
  paired_max_abs_relative_KL_change=float(part.relative_change.max()),
  paired_median_abs_Fz_change=float(part.Fz_delta.median()),
  paired_max_abs_Fz_change=float(part.Fz_delta.max()))
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
