#!/usr/bin/env python3
"""NeuroThermo: Girsanov Fisher 2D, all 264 frozen support scenarios.

Frozen input support is the published 34-row table from NeuroThermo main.
This *new* sensitivity analysis uses published 11x11 nodes, 11 analytically
specified routes, fixed D, deterministic fresh RNG streams. It DOES NOT
pretend to recreate the missing 512 random frozen routes or corresponding
route-specific firing surfaces. No fit, no data-leaking optimization.
"""
from __future__ import annotations
import argparse, json, math, os, sys, time, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from scipy.interpolate import RegularGridInterpolator
from scipy.integrate import cumulative_trapezoid
from concurrent.futures import ProcessPoolExecutor, as_completed
sys.path.insert(0,str(Path(__file__).resolve().parent/'originals'))
from girsanov_hr import D, DT, PRE_MS, STIM_MS, JMAX, rk4_pre
SUPPORT_PATH=Path(__file__).resolve().parent/'originals/core_retained34_from_repo.csv'
GRID=np.linspace(0.,1.,11)

@njit(cache=True)
def sim2d(par,delta,init,scenario_id,ii,jj,nrep,noise_scale,wtj_fixed):
    b,r,s,k,J=par
    db,dlr,ds,dlk,dj=delta
    sx=math.sqrt(2*D[0]*noise_scale*DT)
    sy=math.sqrt(2*D[1]*noise_scale*DT)
    sz=math.sqrt(2*D[2]*noise_scale*DT)
    out=np.zeros((nrep,7),np.float64)
    nsteps=int(round(STIM_MS/DT))
    for n in range(nrep):
        # Diagonal seed family reused exactly from the previous Girsanov run
        if not wtj_fixed and noise_scale==1.0 and ii==jj:
            seed=100_000_000 + scenario_id*100_000 + (ii*3)*1000 + n*101
        else:
            # strictly unique integer for scenario, node and replication;
            # one independent family per noise and fixed-J condition
            seed=777_000_000+scenario_id*60_000 + ii*5_000 + jj*420 + n*101
            if noise_scale<1.0: seed += 11_000_000
            if noise_scale>1.0: seed += 22_000_000
            if wtj_fixed: seed += 33_000_000
        np.random.seed(seed)
        x,y,z=init
        uuv=0.;uv=0.;vv=0.;zz=0.;nx=0;z_peak=0.
        prevx=x;lastsp=-1.e12
        for t in range(nsteps):
            bx=db*x*x
            dv=k*(dlk*J+dj)
            rz=r*(dlr*(s*(x+1.6)-z)+ds*(x+1.6))
            q=0.5*DT/noise_scale
            uuv+=q*(bx*bx/D[0]+rz*rz/D[2])
            uv+=q*bx*dv/D[0]
            vv+=q*dv*dv/D[0]
            zz+=q*rz*rz/D[2]
            fx=y-x*x*x+b*x*x-z+k*J
            fy=1-5*x*x-y
            fz=r*(s*(x+1.6)-z)
            xn=x+DT*fx+sx*np.random.randn()
            yn=y+DT*fy+sy*np.random.randn()
            zn=z+DT*fz+sz*np.random.randn()
            if not (math.isfinite(xn) and math.isfinite(yn) and math.isfinite(zn)) or max(abs(xn),abs(yn),abs(zn))>1e6:
                for kk in range(7):out[n,kk]=math.nan
                break
            if prevx<0<=xn:
                tt=(t-prevx/(xn-prevx))*DT
                if tt-lastsp>=1.0:
                    nx+=1;lastsp=tt
            x,y,z=xn,yn,zn;prevx=xn
        else:
            out[n,0]=uuv;out[n,1]=uv;out[n,2]=vv;out[n,3]=zz
            out[n,4]=nx;out[n,5]=x;out[n,6]=z
    return out

ROUTES=[('legacy_coupled',1.,'linear'),('legacy_drive_early',2.,'early'),('legacy_drive_late',2.,'late')]+[('power_'+str(a),a,'power') for a in (0.25,0.4,0.6,0.8,1.25,1.67,2.5,4.0)]

def build_routes():
    curves={}
    t=np.linspace(0.,1.,40001)
    for name,a,kind in ROUTES:
        if kind=='linear':v=t
        elif kind=='early':v=1-(1-t)**2
        elif kind=='late':v=t*t
        else:v=t**a
        s=np.r_[0.,cumulative_trapezoid(np.hypot(np.gradient(t,t),np.gradient(v,t)),t)]
        s/=s[-1]
        arc=np.linspace(0,1,401)
        u=np.interp(arc,s,t)
        vv=np.interp(arc,s,v)
        du=np.gradient(u,arc);dv=np.gradient(vv,arc)
        curves[name]=(arc,np.column_stack((u,vv)),du,dv)
    return curves

CURVES=None

def process_scenario(item,nrep,noise_scale,fixedj,store_node,save_dir=None):
    sid,wd,sd=item
    w=pd.Series(wd);s=pd.Series(sd)
    wJ=w.J_q75;sJ=s.J_q75
    delta=np.array([s.b-w.b,np.log(s.r/w.r),s.s-w.s,np.log(s.kappa_I/w.kappa_I),0. if fixedj else sJ-wJ],float)
    pre=rk4_pre(float(w.b),float(w.r),float(w.s),float(w.kappa_I),int(round(PRE_MS/DT)),DT)
    if pre[3]!=0: raise RuntimeError(f'baseline spikes WT {w.cell_id} {w.solution_key}')
    init=np.array(pre[:3])
    arrays=np.zeros((11,11,8),float)
    for i,u in enumerate(GRID):
        for j,v in enumerate(GRID):
            par=np.array([w.b+u*delta[0],w.r*np.exp(u*delta[1]),w.s+u*delta[2],w.kappa_I*np.exp(v*delta[3]),wJ+v*delta[4]])
            trials=sim2d(par,delta,init,sid,i,j,nrep,noise_scale,fixedj)
            if not np.all(np.isfinite(trials)):
                raise RuntimeError(f'nonfinite sid={sid} node={i},{j} condition={noise_scale}/{fixedj}')
            arrays[i,j,:4]=np.mean(trials[:,:4],axis=0)
            arrays[i,j,4]=np.mean(trials[:,4])*1000/STIM_MS
            arrays[i,j,5]=np.mean(trials[:,4]>0)
            arrays[i,j,6]=np.std(trials[:,4],ddof=1)*1000/STIM_MS if nrep>1 else 0.
            arrays[i,j,7]=np.mean(trials[:,6])
    uu=arrays[:,:,0];uv=arrays[:,:,1];vv=arrays[:,:,2];zz=arrays[:,:,3]
    det=uu*vv-uv**2
    if det.min() < -1e-6*np.max(uu*vv): raise RuntimeError(f'non-PSD tensor sid={sid}')
    F=uu+2*uv+vv
    if np.min(F)<-1e-6: raise RuntimeError(f'negative Fisher sid={sid}')
    interpolators=[RegularGridInterpolator((GRID,GRID),arrays[:,:,k],bounds_error=True) for k in range(4)]
    rout=[]
    for name,(arc,at,du,dv) in CURVES.items():
        Iuu,Iuv,Ivv,Izz=(gi(at) for gi in interpolators)
        info=du*du*Iuu+2*du*dv*Iuv+dv*dv*Ivv
        iz=du*du*Izz
        # integration by arc-length, as in the frozen route summaries
        cumul=np.r_[0.,cumulative_trapezoid(info,arc)]
        tot=float(cumul[-1]);itz=float(np.trapezoid(iz,arc))
        p50=float(np.interp(tot/2,cumul,arc)) if tot>0 else float('nan')
        rout.append(dict(scenario_id=sid,wt=w.cell_id,sca3=s.cell_id,
          wt_solution=w.solution_key,sca3_solution=s.solution_key,
          scenario_weight=float(w.within_cell_support_weight*s.within_cell_support_weight),
          route=name,noise_scale=noise_scale,fixed_J=fixedj,nrep=nrep,
          s50=p50,Fz=itz/tot if tot>0 else float('nan'),
          total_fisher=tot,zero_spike_nodes=int((arrays[:,:,5]==0).sum()),
          partially_spiking_nodes=int(((arrays[:,:,5]>0)&(arrays[:,:,5]<1)).sum()),
          full_spiking_nodes=int((arrays[:,:,5]==1).sum()),
          min_rate=float(arrays[:,:,4].min()),max_rate=float(arrays[:,:,4].max()),
          min_det=float(det.min()),common_pre_spikes=int(pre[3])))
    if save_dir is not None:
        nodal=pd.DataFrame(dict(u=np.repeat(GRID,11),v=np.tile(GRID,11),
          Iuu=uu.ravel(),Iuv=uv.ravel(),Ivv=vv.ravel(),Izz=zz.ravel(),
          rate_Hz=arrays[:,:,4].ravel(),spiking_fraction=arrays[:,:,5].ravel()))
        nodal.to_csv(save_dir/f'tensor_scenario_{sid:03d}.csv',index=False)
    return rout, int((arrays[:,:,5]==0).sum()),float(det.min())

def worker(p):
    return process_scenario(*p)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--limit',type=int,default=264)
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--nrep',type=int,default=4)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--noise',type=float,default=1.0)
    ap.add_argument('--fixed-J',action='store_true')
    ap.add_argument('--save-nodes',action='store_true')
    a=ap.parse_args()
    if a.noise not in (0.5,1.0,2.0):raise ValueError('choose 0.5 / 1 / 2')
    a.out.mkdir(parents=True,exist_ok=True)
    data=pd.read_csv(SUPPORT_PATH)
    assert len(data)==34 and np.allclose(data.groupby('cell_id').within_cell_support_weight.sum(),1)
    data['J_q75']=data.rheobase_J+0.75*(data.cell_id.map(JMAX)-data.rheobase_J)
    wt=data[data.cell_id.str.startswith('WT_')]
    sc=data[data.cell_id.str.startswith('SCA3_')]
    tasks=[]
    for wc in sorted(wt.cell_id.unique()):
        for sca in sorted(sc.cell_id.unique()):
            for _,w in wt[wt.cell_id==wc].iterrows():
                for _,s in sc[sc.cell_id==sca].iterrows():
                    tasks.append((len(tasks),w.to_dict(),s.to_dict()))
    assert len(tasks)==264
    chosen=tasks[a.start:a.start+a.limit]
    global CURVES
    CURVES=build_routes()
    allr=[]; started=time.perf_counter()
    # workers receive global route curves via Linux fork; use per-scenario task files
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        futs={pool.submit(worker,(item,a.nrep,a.noise,a.fixed_J,a.save_nodes,a.out if a.save_nodes else None)):item[0] for item in chosen}
        for i,fu in enumerate(as_completed(futs)):
            res,zero,det=fu.result();allr.extend(res)
            if (i+1)%10==0 or i+1==len(chosen):
                print(f'PROGRESS {i+1}/{len(chosen)} elapsed={time.perf_counter()-started:.1f}s',flush=True)
            if (i+1)%25==0:
                pd.DataFrame(allr).to_csv(a.out/'checkpoint_routes.csv',index=False)
    df=pd.DataFrame(allr).sort_values(['scenario_id','route'])
    df.to_csv(a.out/'route_scenario_results.csv',index=False)
    fingerprint=hashlib.sha256(SUPPORT_PATH.read_bytes()).hexdigest()
    manifest=dict(n_scenarios=len(chosen),n_pairs=df[['wt','sca3']].drop_duplicates().shape[0],n_routes=len(ROUTES),n_nodes=121,nrep=a.nrep,
        noise_scale=a.noise,fixed_J=a.fixed_J,seed_policy='frozen prior diagonal seeds reused at shared nodes for D=1; new predeclared unique RNG otherwise',
        support_sha256=fingerprint,simulation_dt_ms=DT,pre_ms=PRE_MS,observation_ms=STIM_MS,
        frozen_525_status='UNAVAILABLE original frozen binary with SHA 132d85c9fe10c5b9e50e2cbf0e9ebcb816c084deadf88e8841ec31f26e470d5e',
        elapsed_s=time.perf_counter()-started)
    (a.out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest,indent=2),flush=True)

if __name__=='__main__':main()
