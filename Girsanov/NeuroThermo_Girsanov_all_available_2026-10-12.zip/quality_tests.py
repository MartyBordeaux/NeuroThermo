"""Algebraic and numerical invariants. Exit nonzero if any check fails."""
import sys,json,numpy as np,pandas as pd
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'originals'))
from girsanov_hr import D,path_parameters,rk4_pre,PRE_MS,DT
from endpoint_kl import kernel
sup=pd.read_csv(BASE/'originals/core_retained34_from_repo.csv')
sup['J_q75']=sup.rheobase_J+.75*(sup.cell_id.map(__import__('girsanov_hr').JMAX)-sup.rheobase_J)
w=sup[(sup.cell_id=='WT_04')&(sup.solution_key=='best')].iloc[0]
s=sup[(sup.cell_id=='SCA3_04')&(sup.solution_key=='best')].iloc[0]
p=np.array([.1,.3,.8])
paths,delta=path_parameters(w,s,p)
# finite differences in 3-state drift
rng=np.random.default_rng(20261012)
errs=[]
for v in p:
 A,d=path_parameters(w,s,np.array([v]))
 h=1e-6
 Ap,_=path_parameters(w,s,np.array([v+h]));Am,_=path_parameters(w,s,np.array([v-h]))
 b,r,ss,k,J=A[0];db,dlr,ds,dlk,dj=d
 for _ in range(20):
  x,y,z=rng.normal(size=3)
  fxp=y-x**3+Ap[0,0]*x*x-z+Ap[0,3]*Ap[0,4]
  fxm=y-x**3+Am[0,0]*x*x-z+Am[0,3]*Am[0,4]
  fzp=Ap[0,1]*(Ap[0,2]*(x+1.6)-z)
  fzm=Am[0,1]*(Am[0,2]*(x+1.6)-z)
  exactx=db*x*x+k*(dlk*J+dj)
  exactz=r*(dlr*(ss*(x+1.6)-z)+ds*(x+1.6))
  errs.append(abs((fxp-fxm)/(2*h)-exactx)/max(1,abs(exactx)))
  errs.append(abs((fzp-fzm)/(2*h)-exactz)/max(1,abs(exactz)))
assert max(errs)<1e-8,max(errs)
# Distinct processes coincide => directional KL precisely zero
wp=np.array([w.b,w.r,w.s,w.kappa_I]);init=np.array([-1.6,-10.,1.]);zero=kernel(wp,wp,init,w.J_q75,w.J_q75,1,1,0,1.0,3)
assert (zero[:,0]==0).all() and (zero[:,1]==0).all()
# decomposition and PSD
r=pd.read_csv(BASE/'all264_2d_D/route_scenario_results.csv')
assert (r.min_det>=-1e-6).all()
e=pd.read_csv(BASE/'endpoint_all264/all264_directional_KL.csv')
assert (e.KL_path>=0).all() and (e.KL_x>=0).all() and (e.KL_z>=0).all()
assert np.allclose(e.KL_path,e.KL_x+e.KL_z,atol=1e-7,rtol=1e-12)
assert len(e)==2640 and len(r)==2904
out=dict(status='PASSED',max_relative_central_difference_error=float(max(errs)),identical_model_KL_exact_zero=True,
           n_2d_scenario_route_records=len(r),n_endpoint_scenario_condition_direction_records=len(e),
           tensors_psd=True,endpoint_KL_decomposition_exact=True)
(BASE/'final_analysis/QUALITY_TESTS.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
