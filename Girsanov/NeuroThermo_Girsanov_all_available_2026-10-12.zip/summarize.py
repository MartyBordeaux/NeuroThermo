#!/usr/bin/env python3
"""Pair-balanced, no biological pseudoreplication; report Girsanov sensitivity."""
import json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).parent
OUT=BASE/'final_analysis';OUT.mkdir(exist_ok=True)
S=pd.read_csv(BASE/'all264_2d_D'/'route_scenario_results.csv')
L=pd.read_csv(BASE/'endpoint_all264'/'all264_directional_KL.csv')
OLD=pd.read_csv(BASE/'originals'/'all264_n4'/'scenario_summary.csv')
FIRE=pd.read_csv(BASE/'originals'/'frozen_marker_diagnostic'/'historical_firing_markers_coupled_v13.csv')
assert len(S)==264*11 and len(L)==264*10
assert S.scenario_id.nunique()==264 and L.scenario_id.nunique()==264
assert S.groupby('scenario_id').route.nunique().eq(11).all()
assert L.groupby('scenario_id').size().eq(10).all()

def wavg(values,weights):
    v=np.asarray(values,float);w=np.asarray(weights,float)
    return float(np.average(v,weights=w))

pair_route=[]
for (route,w,s),g in S.groupby(['route','wt','sca3'],sort=True):
    g=g.sort_values('scenario_id');ww=g.scenario_weight.to_numpy();ww/=ww.sum()
    pair_route.append(dict(route=route,wt=w,sca3=s,n_variants=len(g),
      weighted_s50=wavg(g.s50,ww),weighted_Fz=wavg(g.Fz,ww),
      min_s50=float(g.s50.min()),max_s50=float(g.s50.max()),
      s50_range=float(g.s50.max()-g.s50.min()),
      min_Fz=float(g.Fz.min()),max_Fz=float(g.Fz.max()),
      fraction_variants_Fz_gt_50=float(np.dot(ww,(g.Fz>0.5).astype(float))),
      sum_weight=float(g.scenario_weight.sum()),
      scenarios_silent=int((g.zero_spike_nodes>0).sum()),
      max_zero_nodes=int(g.zero_spike_nodes.max())))
PP=pd.DataFrame(pair_route);PP.to_csv(OUT/'pair_balanced_11routes.csv',index=False)

route_sum=[]
for name,g in PP.groupby('route'):
    route_sum.append(dict(route=name,n_pairs=len(g),
      median_pair_s50=float(g.weighted_s50.median()),
      q25_pair_s50=float(g.weighted_s50.quantile(.25)),
      q75_pair_s50=float(g.weighted_s50.quantile(.75)),
      median_pair_Fz=float(g.weighted_Fz.median()),
      n_pairs_Fz_majority=int((g.weighted_Fz>0.5).sum()),
      n_pairs_any_retained_Fz_majority=int((g.max_Fz>0.5).sum()),
      n_pairs_any_silent=int((g.scenarios_silent>0).sum()),
      median_within_pair_s50_range=float(g.s50_range.median())))
RO=pd.DataFrame(route_sum).sort_values('route');RO.to_csv(OUT/'route_summary_11.csv',index=False)

# check interpolation accuracy at coupled path: compare all 264 previous 31-node raw simulations
C=S[S.route=='legacy_coupled'].merge(OLD,on=['scenario_id','wt','sca3','wt_solution','sca3_solution'],validate='one_to_one')
C['delta_2d_31']=C.s50-C.p50_path
C[['scenario_id','wt','sca3','s50','p50_path','delta_2d_31','Fz','integrated_slow_fraction']].to_csv(OUT/'diagonal_11x11_vs_31nodes.csv',index=False)

pair_end=[]
for (proto,noise,ref,w,s),g in L.groupby(['protocol','noise_scale','reference','wt','sca3']):
    weights=g.scenario_weight.to_numpy();weights/=weights.sum()
    pair_end.append(dict(protocol=proto,noise_scale=noise,reference=ref,wt=w,sca3=s,
       n_scenarios=len(g),KL_weighted=wavg(g.KL_path,weights),
       KL_x_weighted=wavg(g.KL_x,weights),KL_z_weighted=wavg(g.KL_z,weights),
       Fz_weighted=wavg(g.F_z,weights),min_KL=float(g.KL_path.min()),max_KL=float(g.KL_path.max()),
       KL_range_ratio=float(g.KL_path.max()/g.KL_path.min()) if min(g.KL_path)>0 else np.nan,
       fraction_silent=wavg(1-g.spiking_fraction,weights),
       MC_CV_weighted=wavg(g.MC_CV,weights)))
END=pd.DataFrame(pair_end);END.to_csv(OUT/'pair_balanced_endpoint_KL.csv',index=False)

# diagonal firing marker matching from historical frozen v1.3
origF=FIRE.rename(columns={'biological_pair_key':'pair'})
C['pair']=C.wt+'__TO__'+C.sca3
C=C.merge(origF[['pair','balance_p_isi_weighted_median','kl_balance_p_median']],on='pair',validate='many_to_one')
C['delta_firing']=C.s50-C.balance_p_isi_weighted_median
C.to_csv(OUT/'diagonal_264_with_firing.csv',index=False)
Pc=PP[PP.route=='legacy_coupled'].copy();Pc['pair']=Pc.wt+'__TO__'+Pc.sca3
Pc=Pc.merge(origF[['pair','balance_p_isi_weighted_median']],on='pair',validate='one_to_one')
Pc['delta_firing']=Pc.weighted_s50-Pc.balance_p_isi_weighted_median
Pc.to_csv(OUT/'diagonal_32_pair_firing.csv',index=False)

# within-scenario route variation: not comparisons to firing (missing route specific marker)
G=S.groupby(['scenario_id','wt','sca3']).agg(s50_min=('s50','min'),s50_max=('s50','max'),
  Fz_min=('Fz','min'),Fz_max=('Fz','max')).reset_index()
G['s50_span']=G.s50_max-G.s50_min
G['Fz_span']=G.Fz_max-G.Fz_min
G.to_csv(OUT/'scenario_11route_sensitivity.csv',index=False)

fig,axes=plt.subplots(1,2,figsize=(12,5.2),layout='constrained')
order=['legacy_coupled','legacy_drive_early','legacy_drive_late']+[n for n in RO.route if n.startswith('power_')]
labels=[x.replace('legacy_','') for x in order]
axes[0].boxplot([PP[PP.route==name].weighted_s50.to_numpy() for name in order],tick_labels=labels,showfliers=False)
axes[1].boxplot([PP[PP.route==name].weighted_Fz.to_numpy() for name in order],tick_labels=labels,showfliers=False)
axes[0].set(ylabel='s50: half cumulative path information',title='32 dependent pairs / 264 retained scenarios',ylim=(0,1))
axes[1].set(ylabel='Slow-state fraction Fz',title='Route and parameter sensitivity',ylim=(0,1))
for ax in axes: ax.tick_params(axis='x',rotation=60)
fig.savefig(OUT/'11routes_pair_summary.png',dpi=170);plt.close(fig)

fig,ax=plt.subplots(figsize=(7.5,5),layout='constrained')
x=Pc.balance_p_isi_weighted_median.to_numpy();y=Pc.weighted_s50.to_numpy()
ax.scatter(x,y,s=32,alpha=.8)
ax.plot([0,1],[0,1],'--',lw=1)
for _,row in Pc.iterrows():
    if row.delta_firing>0.01:ax.annotate(row.wt+'-'+row.sca3.replace('SCA3_','S'),(row.balance_p_isi_weighted_median,row.weighted_s50),fontsize=6)
ax.set(xlim=(0,1),ylim=(0,1),xlabel='Historical diagonal firing balance p',ylabel='New 11x11 Girsanov information midpoint s50',title='Only diagonal: different markers, no causality claim')
fig.savefig(OUT/'diagonal_firing_comparison.png',dpi=170);plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(12,5.2),layout='constrained')
REF=END[(END.protocol=='paired_q75')&(END.noise_scale==1.)]
for ref,marker in [('WT','o'),('SCA3','^')]:
    g=REF[REF.reference==ref]
    axes[0].scatter(g.KL_weighted,g.Fz_weighted,label=ref,marker=marker,alpha=.8)
    axes[1].scatter(g.KL_weighted,g.KL_range_ratio,label=ref,marker=marker,alpha=.8)
axes[0].set(xscale='log',xlabel='Pair-weighted directional path KL (nats)',ylabel='Slow component fraction',title='Girsanov endpoint KL at paired q75')
axes[1].set(xscale='log',yscale='log',xlabel='Pair-weighted directional path KL (nats)',ylabel='Within-pair KL max/min retained',title='Identifiability of endpoint KL')
for ax in axes:ax.legend()
fig.savefig(OUT/'endpoint_pair_KL.png',dpi=170);plt.close(fig)

# Comparable same pair/WT-reference KL reduction by fixing input
W=END[END.reference=='WT'].pivot_table(index=['wt','sca3'],columns=['protocol','noise_scale'],values='KL_weighted')
W.columns=[x[0]+'_'+str(x[1]) for x in W.columns]
W['matched_vs_paired']=W['matched_WT_J_1.0']/W['paired_q75_1.0']
W['no_drive_vs_paired']=W['no_drive_1.0']/W['paired_q75_1.0']
W['noise_half_ratio']=W['paired_q75_0.5']/W['paired_q75_1.0']
W['noise_double_ratio']=W['paired_q75_2.0']/W['paired_q75_1.0']
W.to_csv(OUT/'WT_direction_pair_protocol_ratios.csv')

report={
 'n_scenarios':int(S.scenario_id.nunique()),'n_2d_nodes':121,'n_analytic_routes':11,
 'num_scenario_route_comparisons':int(len(S)),
 'frozen_525_status':'NO: unavailable original route table and route-specific firing readouts',
 'within_scenario_route_s50_span_median':float(G.s50_span.median()),
 'within_scenario_route_s50_span_q75':float(G.s50_span.quantile(.75)),
 'median_pair_s50_span_within_variants_coupled':float(Pc.s50_range.median()),
 'diagonal_discrepancy_median_abs':float(C.delta_2d_31.abs().median()),
 'diagonal_discrepancy_q95_abs':float(C.delta_2d_31.abs().quantile(.95)),
 'diagonal_discrepancy_max_abs':float(C.delta_2d_31.abs().max()),
 'diagonal_discrepancy_gt_0p05':int((C.delta_2d_31.abs()>0.05).sum()),
 'diagonal_pair_deltas_median':float(Pc.delta_firing.median()),
 'diagonal_n_pair_delta_lt_0':int((Pc.delta_firing<0).sum()),
 'n_2d_scenarios_any_silent':int((S.groupby('scenario_id').zero_spike_nodes.max()>0).sum()),
 'num_nodes_no_spike_scenario':int(S[S.route=='legacy_coupled'].zero_spike_nodes.sum()),
 'min_fisher_det':float(S.min_det.min()),
 'pair_route_s50_range':{k:[float(g.weighted_s50.min()),float(g.weighted_s50.max())] for k,g in PP.groupby('route')},
 'no_input_vs_paired_ratio_median':float(W.no_drive_vs_paired.median()),
 'fixed_J_vs_paired_ratio_median':float(W.matched_vs_paired.median()),
 'WT_q75_pair_KL_median':float(W['paired_q75_1.0'].median()),
 'WT_q75_pair_KL_range':[float(W['paired_q75_1.0'].min()),float(W['paired_q75_1.0'].max())],
 'WT_endpoint_no_drive_silent_scenarios':int((L[(L.protocol=='no_drive')&(L.reference=='WT')].spiking_fraction==0).sum()),
 'median_MC_CV_endpoint_KL':float(L.MC_CV.median()),
 'noise_half_KL_ratio_median':float(W.noise_half_ratio.median()),
 'noise_double_KL_ratio_median':float(W.noise_double_ratio.median()),
 'worst_noise_half_KL_ratio':float(W.noise_half_ratio.max()),
 'worst_noise_double_KL_ratio':float(W.noise_double_ratio.max()),
}
(OUT/'RESULTS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps(report,indent=2,ensure_ascii=False))
