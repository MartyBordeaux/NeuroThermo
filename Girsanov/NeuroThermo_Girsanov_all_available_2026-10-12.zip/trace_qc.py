"""Actual membrane-state traces and spike trains, frozen 0-crossing event definition."""
from pathlib import Path
import math,sys
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from numba import njit
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'originals'))
from girsanov_hr import rk4_pre,DT,PRE_MS,JMAX,D
support=pd.read_csv(BASE/'originals/core_retained34_from_repo.csv')
support['J_q75']=support.rheobase_J+.75*(support.cell_id.map(JMAX)-support.rheobase_J)
@njit(cache=True)
def sim(b,r,s,k,J,start,seed):
    np.random.seed(seed)
    x,y,z=start
    dt=.025;nsteps=40000;skip=20
    trace=np.empty((nsteps//skip,5),float)
    sp=0;lastsp=-1e12;prevx=x
    for i in range(nsteps):
        fx=y-x*x*x+b*x*x-z+k*J
        fy=1-5*x*x-y
        fz=r*(s*(x+1.6)-z)
        xn=x+fx*dt+np.sqrt(2*D[0]*dt)*np.random.randn()
        yn=y+fy*dt+np.sqrt(2*D[1]*dt)*np.random.randn()
        zn=z+fz*dt+np.sqrt(2*D[2]*dt)*np.random.randn()
        if prevx<0<=xn:
            tt=(i-prevx/(xn-prevx))*dt
            if tt-lastsp>=1.:sp+=1;lastsp=tt
        x,y,z=xn,yn,zn;prevx=x
        if (i+1)%skip==0:
            pos=(i+1)//skip-1
            trace[pos,0]=(i+1)*dt
            trace[pos,1]=x
            trace[pos,2]=y
            trace[pos,3]=z
            trace[pos,4]=sp
    return trace
out=BASE/'trace_qc';out.mkdir(exist_ok=True)
rows=[]
for wt,sca in [('WT_04','SCA3_04'),('WT_09','SCA3_06'),('WT_14','SCA3_01')]:
    w=support[(support.cell_id==wt)&(support.solution_key=='best')].iloc[0]
    s=support[(support.cell_id==sca)&(support.solution_key=='best')].iloc[0]
    start=np.array(rk4_pre(w.b,w.r,w.s,w.kappa_I,int(round(PRE_MS/DT)),DT)[:3])
    fig,axs=plt.subplots(3,3,figsize=(12,6.5),sharex=True,layout='constrained')
    for col,(protocol,jw,js) in enumerate([('paired_q75',w.J_q75,s.J_q75),('matched_WT_J',w.J_q75,w.J_q75),('zero_input',0.,0.)]):
        for row,(frac,label) in enumerate([(0.0,'WT'),(0.5,'intermediate'),(1.,'SCA3')]):
            p=np.array([w.b+frac*(s.b-w.b),np.exp((1-frac)*np.log(w.r)+frac*np.log(s.r)),w.s+frac*(s.s-w.s),np.exp((1-frac)*np.log(w.kappa_I)+frac*np.log(s.kappa_I)),jw+frac*(js-jw)])
            ar=sim(*p,start,832301+10000*row+123*col+int(wt.split('_')[1]))
            axs[row,col].plot(ar[:,0],ar[:,1],lw=.55)
            axs[row,col].set_ylabel(f'{label}: x')
            if row==0:axs[row,col].set_title(protocol)
            rows.append(dict(pair=wt+'__TO__'+sca,protocol=protocol,p=frac,spike_count=int(ar[-1,4]),mean_x=float(ar[:,1].mean()),min_x=float(ar[:,1].min()),max_x=float(ar[:,1].max()),mean_z=float(ar[:,3].mean())))
            if col==0:pd.DataFrame(ar,columns=['time_ms','x','y','z','cumulative_spike_count']).to_csv(out/f'trace_{wt}_{sca}_p{int(frac*100)}_{protocol}.csv',index=False)
    for ax in axs[-1,:]:ax.set_xlabel('Time (ms)')
    fig.suptitle(f'{wt} vs {sca} / best fits: actual x(t), not firing-rate-only',fontsize=12)
    fig.savefig(out/f'waveform_{wt}_{sca}.png',dpi=145)
    plt.close(fig)
pd.DataFrame(rows).to_csv(out/'trace_spike_qc.csv',index=False)
print(pd.DataFrame(rows).groupby('protocol').spike_count.agg(['min','median','max','size']))
