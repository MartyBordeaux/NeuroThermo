#!/usr/bin/env python3
"""Descriptive, no-refit comparison on the published coupled-diagonal path.

Important: A Girsanov information-median position is not a WT/SCA3
KL-affinity balance. This code never renames p50 as a balance boundary.
Requires exactly the 32 pair-marker rows exported from the historical
publication/plos-v1.3 figure-source branch, and the previously audited
264 retained-scenario diagonal Girsanov pilot.
"""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

HERE=Path(__file__).resolve().parent
PILOT=HERE.parent/'all264_n4'/'scenario_summary.csv'
MARKERS=HERE/'historical_firing_markers_coupled_v13.csv'
assert PILOT.is_file() and MARKERS.is_file()
p=pd.read_csv(PILOT)
m=pd.read_csv(MARKERS)
assert len(p)==264 and len(m)==32
assert p[['wt','sca3','wt_solution','sca3_solution']].notna().all().all()
assert m.biological_pair_key.is_unique
p['biological_pair_key']=p.wt+'__TO__'+p.sca3
x=p.merge(m,on='biological_pair_key',validate='many_to_one',how='inner')
assert len(x)==264 and x.biological_pair_key.nunique()==32
assert (x.groupby('biological_pair_key').size()==x.groupby('biological_pair_key').n_support_scenarios.first()).all()
assert np.allclose(x.groupby('biological_pair_key').scenario_weight.sum(),1,atol=1e-12)
assert np.allclose(x.valid_trajectory_fraction,1.)
x['delta_p50_minus_firing']=x.p50_path-x.balance_p_isi_weighted_median
x['delta_p50_minus_kl']=x.p50_path-x.kl_balance_p_median
x['best_fit']=(x.wt_solution=='best')&(x.sca3_solution=='best')

def wquant(vals,wei,q):
    v=np.asarray(vals,float);w=np.asarray(wei,float)
    order=np.argsort(v,kind='stable');v=v[order];w=w[order];w=w/w.sum()
    return float(v[np.searchsorted(np.cumsum(w),q,side='left')])

out=[]
for key,g in x.groupby('biological_pair_key',sort=True):
    w=g.scenario_weight.to_numpy(); assert w.sum()>0
    fir=float(g.balance_p_isi_weighted_median.iloc[0]);kl=float(g.kl_balance_p_median.iloc[0]);
    z=g.integrated_slow_fraction.to_numpy();pp=g.p50_path.to_numpy(); bf=g.loc[g.best_fit]
    assert len(bf)==1
    d=pp-fir
    row=dict(pair=key,wt=g.wt.iloc[0],sca3=g.sca3.iloc[0],n_scenarios=len(g),
             firing_balance_p=fir,historical_kl_balance_p=kl,
             p50_weighted_mean=float(np.average(pp,weights=w)),p50_weighted_median=wquant(pp,w,.5),
             p50_weighted_q25=wquant(pp,w,.25),p50_weighted_q75=wquant(pp,w,.75),
             p50_range=float(np.ptp(pp)),
             Fz_weighted_mean=float(np.average(z,weights=w)),
             Fz_min=float(z.min()),Fz_max=float(z.max()),Fz_range=float(np.ptp(z)),
             delta_weighted_mean=float(np.average(d,weights=w)),
             delta_weighted_median=wquant(d,w,.5),
             delta_best=float(bf.p50_path.iloc[0]-fir),
             weight_before_firing=float(w[d<0].sum()),
             weight_after_firing=float(w[d>0].sum()),
             all_retained_before=bool(np.all(d<0)),
             all_retained_after=bool(np.all(d>0)),
             both_signs=bool(np.any(d<0) and np.any(d>0)),
             silence_any=bool((g.n_zero_spike_nodes>0).any()),
             best_silent=bool((bf.n_zero_spike_nodes>0).any()))
    out.append(row)
q=pd.DataFrame(out)
assert len(q)==32
x.to_csv(HERE/'scenario_comparison_264.csv',index=False)
q.to_csv(HERE/'pair_balanced_32.csv',index=False)

allpair_delta=q.delta_weighted_mean.to_numpy()
by_wt=q.groupby('wt').delta_weighted_mean.mean()
by_sca=q.groupby('sca3').delta_weighted_mean.mean()
# Diagnostic jackknife, not a population confidence interval.
lo_wt=[np.median(q[q.wt!=w].delta_weighted_mean) for w in sorted(q.wt.unique())]
lo_sca=[np.median(q[q.sca3!=s].delta_weighted_mean) for s in sorted(q.sca3.unique())]
# Wilson intervals/p-values deliberately omitted: pairs share endpoints.
res={
 'analysis':'HISTORICAL_DIAGONAL_MARKER_DIAGNOSTIC_NOT_FROZEN_525_VALIDATION',
 'n_retained_scenarios':int(len(x)), 'n_pairs':int(len(q)),
 'p50_marker_definition':'position of half integrated path Fisher information on fixed coupled diagonal',
 'firing_marker_definition':'historically frozen pair-specific ISI/rheobase A_ISI=0.5 balance marker',
 'kl_marker_definition':'historically frozen endpoint-relative KL balance marker, NOT path KL',
 'pair_median_p50_weighted_mean':float(np.median(q.p50_weighted_mean)),
 'pair_median_firing':float(np.median(q.firing_balance_p)),
 'pair_median_p50_minus_firing_weighted_mean':float(np.median(allpair_delta)),
 'pair_q25_q75_p50_minus_firing':[float(v) for v in np.quantile(allpair_delta,[.25,.75])],
 'pair_weighted_mean_delta_negative':int((allpair_delta<0).sum()),
 'pair_all_retained_before':int(q.all_retained_before.sum()),
 'pair_all_retained_after':int(q.all_retained_after.sum()),
 'pair_both_signs':int(q.both_signs.sum()),
 'best_fit_delta_negative_pairs':int((q.delta_best<0).sum()),
 'median_within_pair_retained_p50_range':float(q.p50_range.median()),
 'median_retained_weight_before_firing':float(q.weight_before_firing.median()),
 'pairs_any_silent_windows':int(q.silence_any.sum()),
 'pair_median_delta_leave_one_wt_range':[float(min(lo_wt)),float(max(lo_wt))],
 'pair_median_delta_leave_one_sca3_range':[float(min(lo_sca)),float(max(lo_sca))],
 'rho_pair_delta_Fz':float(spearmanr(q.delta_weighted_mean,q.Fz_weighted_mean).statistic),
 'source_fingerprint_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in {'pilot':PILOT,'historical_markers':MARKERS}.items()},
 'critical_warning':'Different information and balance markers. Ordering cannot independently confirm state-before-firing or all 525 routes.',
}
(HERE/'summary.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')

fig,axs=plt.subplots(1,2,figsize=(12,5.6))
pos=np.arange(32); zz=q.sort_values('delta_weighted_mean').reset_index(drop=True)
axs[0].hlines(pos,zz.p50_weighted_q25-zz.firing_balance_p,zz.p50_weighted_q75-zz.firing_balance_p,linewidth=2,alpha=.75,label='retained support IQR')
axs[0].scatter(zz.delta_weighted_mean,pos,s=30,label='within-pair weighted mean')
axs[0].scatter(zz.delta_best,pos,s=10,marker='x',label='best fit')
axs[0].axvline(0,ls='--',lw=1,c='black')
axs[0].set_yticks(pos,zz.pair,fontsize=5.3)
axs[0].set_xlabel('Girsanov p50 - historical firing balance p')
axs[0].set_title('Coupled diagonal / 32 dependent pairs')
axs[0].legend(fontsize=7,loc='lower right')
axs[1].scatter(q.Fz_weighted_mean,q.delta_weighted_mean,s=45)
for _,r in q.nlargest(4,'Fz_weighted_mean').iterrows():
    axs[1].annotate(r.wt+' / '+r.sca3,(r.Fz_weighted_mean,r.delta_weighted_mean),fontsize=7)
axs[1].axhline(0,ls='--',lw=1,c='black')
axs[1].set_xlabel('Within-pair weighted slow contribution Fz')
axs[1].set_ylabel('Within-pair weighted [p50 - firing]')
axs[1].set_title('Nonunique mechanistic attribution')
fig.tight_layout()
fig.savefig(HERE/'historical_pair_diagnostic.png',dpi=175)
plt.close(fig)
print(json.dumps(res,ensure_ascii=False,indent=2))
