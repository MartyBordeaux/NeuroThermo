#!/usr/bin/env python3
"""Finite-time Girsanov path Fisher for frozen NeuroThermo HR endpoints.

Scientifically separate from the original 2026-08-03 five-fold F-I benchmark.
No refit, no redefinition of retained support or endpoint weights.

The 34-row offline CSV was transcribed from the immutable GitHub source
results/endpoint_ensemble_v1_0_1/transition_ready_endpoint_support.csv
for the 12 core-secure cells; compare it against the original before publication.
"""
from __future__ import annotations
import argparse, hashlib, json, math, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from scipy.integrate import cumulative_trapezoid
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

D = np.array([0.0025, 0.01, 0.00025], dtype=np.float64)
DT = 0.025       # ms, manuscript frozen primary stochastic dt
PRE_MS = 500.0   # ms, manuscript frozen zero-input relaxation
STIM_MS = 1000.0 # ms, manuscript frozen current step
PGRID = np.linspace(0.0, 1.0, 31) # existing HS coupled path grid
X_INITIAL = (-1.6, -10.0, 1.0)
# Frozen observed maximum spiking-current densities, not reoptimized values.
# Source: Hatano-Sasa/core_endpoints_best_q75.csv, NeuroThermo main.
JMAX = {
 "WT_03":3.3079316850849,"WT_04":1.23517777868021,
 "WT_08":0.953908790661435,"WT_09":1.52573132139414,
 "WT_10":1.43431738962109,"WT_13":0.915514250540836,
 "WT_14":1.94138627671071,"WT_16":1.36207684111003,
 "SCA3_01":8.83702269749959,"SCA3_04":7.18549793532442,
 "SCA3_06":7.36876067194935,"SCA3_09":4.87442867445855,
}

@njit(cache=True)
def drift(x,y,z,b,r,s,kappa,J):
    return y-x*x*x+b*x*x-z+kappa*J, 1.0-5*x*x-y, r*(s*(x+1.6)-z)

@njit(cache=True)
def rk4_pre(b,r,s,kappa,steps,dt):
    x,y,z = -1.6,-10.0,1.0
    ns = 0; lastx=x
    for i in range(steps):
        k1=drift(x,y,z,b,r,s,kappa,0.0)
        k2=drift(x+0.5*dt*k1[0],y+0.5*dt*k1[1],z+0.5*dt*k1[2],b,r,s,kappa,0.0)
        k3=drift(x+0.5*dt*k2[0],y+0.5*dt*k2[1],z+0.5*dt*k2[2],b,r,s,kappa,0.0)
        k4=drift(x+dt*k3[0],y+dt*k3[1],z+dt*k3[2],b,r,s,kappa,0.0)
        x += dt*(k1[0]+2*k2[0]+2*k3[0]+k4[0])/6.
        y += dt*(k1[1]+2*k2[1]+2*k3[1]+k4[1])/6.
        z += dt*(k1[2]+2*k2[2]+2*k3[2]+k4[2])/6.
        if lastx < 0.0 and x >= 0.0: ns+=1
        lastx=x
    return x,y,z,ns

@njit(cache=True)
def run_point(pars, dd, init, dt, nsteps, nrep, seed_base, noise_scale):
    """Return per-trajectory integrals and 0.5-ms x,y,z for replicate 0.

    Path Fisher: I=(1/2) E int (d_p f)^T D^-1 (d_p f) d tau.
    Return Ix, Iz, parameter squares/cross contributions, spike count, ISI.
    """
    b,r,s,kappa,J = pars
    db,dr_log,ds,dk_log,dJ = dd
    sigx=math.sqrt(2*D[0]*noise_scale*dt)
    sigy=math.sqrt(2*D[1]*noise_scale*dt)
    sigz=math.sqrt(2*D[2]*noise_scale*dt)
    accum=np.empty((nrep,11),dtype=np.float64)
    keepstep=int(round(0.5/dt)); nt=nsteps//keepstep
    trace=np.full((nt,4),np.nan)
    for rep in range(nrep):
        np.random.seed(seed_base + 101*rep)
        x,y,z=init
        ints=np.zeros(8,np.float64)
        ct=0; isi_sum=0.; isi_n=0; lastspike=-1e12
        prevx=x
        for ii in range(nsteps):
            # Two x-drift components (curvature, drive), two z components (r, s).
            xb=db*x*x
            xd=kappa*(dk_log*J+dJ)
            zr=r*dr_log*(s*(x+1.6)-z)
            zs=r*ds*(x+1.6)
            sx=dt/(2.0*D[0]*noise_scale)
            sz=dt/(2.0*D[2]*noise_scale)
            ints[0]+=sx*(xb+xd)*(xb+xd)
            ints[1]+=sz*(zr+zs)*(zr+zs)
            ints[2]+=sx*xb*xb
            ints[3]+=sx*xd*xd
            ints[4]+=sx*2*xb*xd
            ints[5]+=sz*zr*zr
            ints[6]+=sz*zs*zs
            ints[7]+=sz*2*zr*zs
            fx,fy,fz=drift(x,y,z,b,r,s,kappa,J)
            xn=x+dt*fx+sigx*np.random.randn()
            yn=y+dt*fy+sigy*np.random.randn()
            zn=z+dt*fz+sigz*np.random.randn()
            if not (np.isfinite(xn) and np.isfinite(yn) and np.isfinite(zn)) or max(abs(xn),abs(yn),abs(zn))>1e6:
                accum[rep,:]=np.nan
                break
            if prevx<0.0 and xn>=0.0:
                tt=(ii+(0.0-prevx)/(xn-prevx))*dt
                if tt-lastspike>=1.0:
                    if ct>0: isi_sum+=tt-lastspike; isi_n+=1
                    lastspike=tt; ct+=1
            x,y,z=xn,yn,zn
            prevx=x
            if rep==0 and (ii+1)%keepstep==0:
                ix=(ii+1)//keepstep-1
                trace[ix,0]=(ii+1)*dt
                trace[ix,1]=x; trace[ix,2]=y; trace[ix,3]=z
        else:
            for kk in range(8):accum[rep,kk]=ints[kk]
            accum[rep,8]=ct
            accum[rep,9]=isi_sum/isi_n if isi_n>0 else np.nan
            accum[rep,10]=x
    return accum,trace

def path_parameters(w,s,p):
    out=np.empty((len(p),5),float)
    out[:,0]=(1-p)*w.b + p*s.b
    out[:,1]=np.exp((1-p)*np.log(w.r)+p*np.log(s.r))
    out[:,2]=(1-p)*w.s+p*s.s
    out[:,3]=np.exp((1-p)*np.log(w.kappa_I)+p*np.log(s.kappa_I))
    out[:,4]=(1-p)*w.J_q75+p*s.J_q75
    deriv=np.array([s.b-w.b,np.log(s.r/w.r),s.s-w.s,
                    np.log(s.kappa_I/w.kappa_I),s.J_q75-w.J_q75],float)
    return out,deriv

def find_cumulative_middle(x,y):
    cum=np.r_[0.0,cumulative_trapezoid(y,x)]
    if not np.isfinite(cum[-1]) or cum[-1]<=0:return np.nan
    return float(np.interp(0.5*cum[-1],cum,x))

def run_scenario(w,s,scenario_id,nrep,noise_scale,output,save_traces=False):
    p=PGRID
    path,dp=path_parameters(w,s,p)
    # Common start for every p: deterministic WT zero-input baseline, not p-specific.
    # This isolates drift KL without initial-distribution KL.
    initial=rk4_pre(w.b,w.r,w.s,w.kappa_I,int(round(PRE_MS/DT)),DT)
    if not np.all(np.isfinite(initial[:3])):raise RuntimeError('nonfinite pre-simulation')
    rows=[]
    for i,par in enumerate(path):
        a,tr=run_point(par,dp,np.array(initial[:3]),DT,int(round(STIM_MS/DT)),nrep,
                       100_000_000+scenario_id*100_000+i*1000,noise_scale)
        good=np.all(np.isfinite(a[:,0:9]),axis=1)
        ix=float(np.nanmean(a[:,0])); iz=float(np.nanmean(a[:,1])); ip=ix+iz
        rows.append(dict(scenario_id=scenario_id,wt=w.cell_id,sca3=s.cell_id,
                         wt_solution=w.solution_key,sca3_solution=s.solution_key,
                         scenario_weight=w.within_cell_support_weight*s.within_cell_support_weight,
                         p=float(p[i]),p_index=i,noise_scale=noise_scale,nrep=nrep,
                         valid_trajectories=int(good.sum()),
                         I_x=ix,I_z=iz,I_path=ip,F_z=iz/ip if ip>0 else np.nan,
                         I_x_b=float(np.nanmean(a[:,2])),I_x_drive=float(np.nanmean(a[:,3])),
                         I_x_cross=float(np.nanmean(a[:,4])),I_z_r=float(np.nanmean(a[:,5])),
                         I_z_s=float(np.nanmean(a[:,6])),I_z_cross=float(np.nanmean(a[:,7])),
                         rate_Hz=float(np.nanmean(a[:,8]))*1000./STIM_MS,
                         rate_sd_Hz=float(np.nanstd(a[:,8],ddof=1))*1000./STIM_MS if nrep>1 else np.nan,
                         mean_ISI_ms=float(np.nanmean(a[:,9])) if np.isfinite(a[:,9]).any() else np.nan,
                         spiking_fraction=float((a[:,8]>0).mean()),
                         start_WT_pre_spikes=int(initial[3]),
                         b=par[0],r=par[1],s=par[2],kappa_I=par[3],J_q75=par[4]))
        if save_traces and i in (0,7,15,23,30):
            np.savez_compressed(output/f'trace_{w.cell_id}_{s.cell_id}_{w.solution_key}_{s.solution_key}_p{i:02d}.npz',trace=tr,p=p[i],par=par)
    df=pd.DataFrame(rows)
    if (df.valid_trajectories<nrep).any():
        warnings.warn(f'INCOMPLETE {w.cell_id}/{s.cell_id}: numerical diverged')
    ip=df.I_path.to_numpy(); iz=df.I_z.to_numpy()
    mid=find_cumulative_middle(p,ip)
    integ=float(np.trapezoid(ip,p)); sz=float(np.trapezoid(iz,p))
    summ=dict(scenario_id=scenario_id,wt=w.cell_id,sca3=s.cell_id,
              wt_solution=w.solution_key,sca3_solution=s.solution_key,
              scenario_weight=float(w.within_cell_support_weight*s.within_cell_support_weight),
              p50_path=float(mid),total_path_information=integ,
              integrated_slow_fraction=sz/integ if integ>0 else np.nan,
              n_zero_spike_nodes=int((df.spiking_fraction==0.0).sum()),
              n_partial_spike_nodes=int(((df.spiking_fraction>0)&(df.spiking_fraction<1)).sum()),
              pre_WT_baseline_spikes=int(initial[3]),
              valid_trajectory_fraction=float(df.valid_trajectories.sum()/(nrep*len(p))))
    return df,summ

def main():
    pa=argparse.ArgumentParser()
    pa.add_argument('--support',type=Path,default=Path(__file__).with_name('core_retained34_from_repo.csv'))
    pa.add_argument('--out',type=Path,default=Path(__file__).with_name('girsanov_output'))
    pa.add_argument('--nrep',type=int,default=16)
    pa.add_argument('--noise-scale',type=float,default=1.0,choices=[0.5,1.,2.])
    pa.add_argument('--pair',nargs=2,metavar=('WT','SCA3'),default=None)
    pa.add_argument('--best-only',action='store_true')
    a=pa.parse_args()
    if a.nrep<2:raise ValueError('nrep >= 2 required for QC')
    a.out.mkdir(parents=True,exist_ok=True)
    f=a.support.read_bytes(); support=pd.read_csv(a.support)
    assert len(support)==34 and set(support.cell_id)==set(JMAX)
    assert np.allclose(support.groupby('cell_id').within_cell_support_weight.sum(),1.0)
    support['J_q75']=support.rheobase_J+0.75*(support.cell_id.map(JMAX)-support.rheobase_J)
    wt=support[support.cell_id.str.startswith('WT_')]
    sc=support[support.cell_id.str.startswith('SCA3_')]
    allsc=[]
    pairs=[(w,s) for wc in sorted(wt.cell_id.unique()) for sca in sorted(sc.cell_id.unique())
           for _,w in wt[wt.cell_id==wc].iterrows() for _,s in sc[sc.cell_id==sca].iterrows()]
    assert len(pairs)==264
    for i,(w,s) in enumerate(pairs):
        if a.pair is not None and (w.cell_id,s.cell_id)!=tuple(a.pair):continue
        if a.best_only and (w.solution_key!='best' or s.solution_key!='best'):continue
        allsc.append((i,w,s))
    curves=[]; summ=[]
    for k,(i,w,s) in enumerate(allsc):
        df,sm=run_scenario(w,s,i,a.nrep,a.noise_scale,a.out,save_traces=(k==0))
        curves.append(df);summ.append(sm)
        if (k+1)%10==0 or k==0 or k==len(allsc)-1:
            print(f"{k+1:3d}/{len(allsc)}: {w.cell_id}/{s.cell_id} {w.solution_key}/{s.solution_key} p50={sm['p50_path']:.3f} Fz={sm['integrated_slow_fraction']:.3f}",flush=True)
    df=pd.concat(curves,ignore_index=True); ss=pd.DataFrame(summ)
    df.to_csv(a.out/'path_information_grid.csv',index=False)
    ss.to_csv(a.out/'scenario_summary.csv',index=False)
    pair_rows=[]
    for (wc,sc),g in ss.groupby(['wt','sca3'],sort=True):
        w=g.scenario_weight.to_numpy();w=w/w.sum()
        pair_rows.append(dict(wt=wc,sca3=sc,n_scenarios=len(g),
            p50_weighted_mean=float(np.dot(w,g.p50_path)),
            p50_min=float(g.p50_path.min()),p50_max=float(g.p50_path.max()),
            Fz_weighted_mean=float(np.dot(w,g.integrated_slow_fraction)),
            Fz_min=float(g.integrated_slow_fraction.min()),Fz_max=float(g.integrated_slow_fraction.max()),
            valid_fraction_min=float(g.valid_trajectory_fraction.min()),
            silent_scenarios=int((g.n_zero_spike_nodes>0).sum())))
    pp=pd.DataFrame(pair_rows);pp.to_csv(a.out/'pair_summary.csv',index=False)
    manifest=dict(input_support_sha256=hashlib.sha256(f).hexdigest(),
          source_link='https://github.com/MartyBordeaux/NeuroThermo/blob/main/results/endpoint_ensemble_v1_0_1/transition_ready_endpoint_support.csv',
          q75_source='https://github.com/MartyBordeaux/NeuroThermo/blob/main/Hatano-Sasa/core_endpoints_best_q75.csv',
          n_support_rows=34,n_all_frozen_scenarios=264,n_completed_scenarios=len(ss),
          n_pairs=len(pp),n_path_positions=31,dt_ms=DT,pre_ms=PRE_MS,stimulus_ms=STIM_MS,
          noise_scale=a.noise_scale,D=list(D*a.noise_scale),replicates=a.nrep,
          independent_noise_seed_base=100_000_000,
          initial_distribution='per-WT deterministic 500-ms zero-input reference, COMMON to every p in pair',
          interpretation='finite-time Girsanov Fisher (model path law), not physical entropy production',
          result_status='PILOT_SINGLE_ROUTE_NOT_FROZEN_525_ROUTE_VALIDATION')
    (a.out/'run_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    if len(ss):
        q=curves[0];fig,axs=plt.subplots(2,1,figsize=(7.2,7.5),sharex=True)
        axs[0].plot(q.p,q.I_path,label='I_path');axs[0].plot(q.p,q.I_x,label='I_x');axs[0].plot(q.p,q.I_z,label='I_z')
        axs[0].set_ylabel('Fisher, nats / p²');axs[0].legend()
        axs[1].plot(q.p,q.F_z,label='F_z');axs[1].plot(q.p,q.spiking_fraction,label='spiking fraction')
        axs[1].set(xlabel='WT–SCA3 coupled path p',ylabel='fraction',ylim=(-0.05,1.05));axs[1].legend()
        fig.tight_layout();fig.savefig(a.out/'pilot_path.png',dpi=180);plt.close(fig)
        import glob
        fl=sorted(a.out.glob('trace_*.npz'))
        if fl:
            fig,axs=plt.subplots(len(fl),1,figsize=(9,1.7*len(fl)),sharex=True)
            for ax,f in zip(np.atleast_1d(axs),fl):
                d=np.load(f); t=d['trace']; ax.plot(t[:,0],t[:,1],lw=.7);ax.set_ylabel('x(t)');ax.set_title(f'p={float(d["p"]):.2f}',fontsize=9)
            axs[-1].set_xlabel('time (ms)');fig.tight_layout();fig.savefig(a.out/'pilot_spikes.png',dpi=180);plt.close(fig)
    print(json.dumps({'scenarios':len(ss),'pairs':len(pp),'median_p50':ss.p50_path.median(),
        'median_Fz':ss.integrated_slow_fraction.median(),'silent_scenarios':int((ss.n_zero_spike_nodes>0).sum())},indent=2))

if __name__=='__main__':main()
