#!/usr/bin/env python3
"""Exact finite-horizon Girsanov KL between HR endpoints, fixed common initial state.

No stationarity assumption or physical-energy interpretation. 264 retained support
scenarios, same diagonal diffusion within each comparison. Outputs directional
KL + x/z coordinate contribution, spiking QC. Prescribed paired-q75 and
secondary fixed-J protocols; not a test of frozen 525 route boundaries.
"""
import argparse, hashlib, json, math, sys, time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
from numba import njit
sys.path.insert(0,str(Path(__file__).resolve().parent/'originals'))
from girsanov_hr import D,DT,PRE_MS,STIM_MS,JMAX,rk4_pre
SUPPORT=Path(__file__).resolve().parent/'originals/core_retained34_from_repo.csv'

@njit(cache=True)
def kernel(w,s,start,Jw,Js,sid,prot_id,ref_id,noise,nrep):
    bxw,rw,sw,kw=w
    bxs,rs,ss,ks=s
    bdiff=bxw-bxs
    ddrive=kw*Jw-ks*Js
    zxa=rw*sw-rs*ss
    zzb=rs-rw
    if ref_id==0:
        b,r,ssr,k,J=bxw,rw,sw,kw,Jw
    else:
        b,r,ssr,k,J=bxs,rs,ss,ks,Js
    dxcoeff=DT/(4*D[0]*noise)
    dzcoeff=DT/(4*D[2]*noise)
    sigx=math.sqrt(2*D[0]*noise*DT)
    sigy=math.sqrt(2*D[1]*noise*DT)
    sigz=math.sqrt(2*D[2]*noise*DT)
    steps=int(round(STIM_MS/DT))
    out=np.empty((nrep,9),np.float64)
    for j in range(nrep):
        seed=50_000_000+sid*80_000+prot_id*15_000+ref_id*7_000+j*103
        if noise<1.: seed+=41_000_000
        if noise>1.: seed+=87_000_000
        np.random.seed(seed)
        x,y,z=start
        ix=0.;iz=0.;ns=0;isi=0.;nisi=0;lastsp=-1.e12
        xmin=x;xmax=x;zmin=z;zmax=z
        prevx=x
        for i in range(steps):
            fxdelta=bdiff*x*x+ddrive
            fzdelta=zxa*(x+1.6)+zzb*z
            ix+=dxcoeff*fxdelta*fxdelta
            iz+=dzcoeff*fzdelta*fzdelta
            fx=y-x*x*x+b*x*x-z+k*J
            fy=1.-5*x*x-y
            fz=r*(ssr*(x+1.6)-z)
            xn=x+DT*fx+sigx*np.random.randn()
            yn=y+DT*fy+sigy*np.random.randn()
            zn=z+DT*fz+sigz*np.random.randn()
            if not (math.isfinite(xn) and math.isfinite(yn) and math.isfinite(zn)) or max(abs(xn),abs(yn),abs(zn))>1e6:
                for h in range(9):out[j,h]=np.nan
                break
            if prevx<0. and xn>=0.:
                st=(i-prevx/(xn-prevx))*DT
                if st-lastsp>=1.:
                    if ns>0:isi+=st-lastsp;nisi+=1
                    ns+=1;lastsp=st
            x,y,z=xn,yn,zn;prevx=x
            xmin=min(xmin,x);xmax=max(xmax,x)
            zmin=min(zmin,z);zmax=max(zmax,z)
        else:
            out[j,0]=ix;out[j,1]=iz;out[j,2]=ns
            out[j,3]=isi/nisi if nisi>0 else np.nan
            out[j,4]=xmin;out[j,5]=xmax;out[j,6]=zmin;out[j,7]=zmax
            out[j,8]=x
    return out

def process(item,nrep):
    sid,ww,ss=item;w=pd.Series(ww);s=pd.Series(ss)
    wpars=np.array([w.b,w.r,w.s,w.kappa_I],float)
    spars=np.array([s.b,s.r,s.s,s.kappa_I],float)
    pre=rk4_pre(w.b,w.r,w.s,w.kappa_I,int(round(PRE_MS/DT)),DT)
    if pre[3]!=0:raise RuntimeError(f'WT zero-drive baseline spiking scenario {sid}')
    init=np.array(pre[:3],float)
    outs=[]
    jw=w.J_q75;js=s.J_q75
    protocols=[('paired_q75',jw,js,1.0),('matched_WT_J',jw,jw,1.0),('no_drive',0.,0.,1.0),
               ('paired_q75',jw,js,0.5),('paired_q75',jw,js,2.0)]
    for ip,(proto,Jw,Js,noise) in enumerate(protocols):
        for ref in range(2):
            a=kernel(wpars,spars,init,Jw,Js,sid,ip,ref,noise,nrep)
            if not np.isfinite(a[:,[0,1,2,4,5,6,7,8]]).all(): raise RuntimeError(f'nonfinite sid{sid} {proto} {ref} {noise}')
            ix=np.mean(a[:,0]);iz=np.mean(a[:,1]);tot=ix+iz
            outs.append(dict(scenario_id=sid,wt=w.cell_id,sca3=s.cell_id,
                wt_solution=w.solution_key,sca3_solution=s.solution_key,
                scenario_weight=w.within_cell_support_weight*s.within_cell_support_weight,
                protocol=proto,noise_scale=noise,reference=('WT' if ref==0 else 'SCA3'),
                J_WT=float(Jw),J_SCA3=float(Js),
                KL_path=float(tot),KL_x=float(ix),KL_z=float(iz),F_z=float(iz/tot) if tot>0 else np.nan,
                MC_SE=float(np.std(a[:,0]+a[:,1],ddof=1)/math.sqrt(nrep)),
                MC_CV=float(np.std(a[:,0]+a[:,1],ddof=1)/np.mean(a[:,0]+a[:,1])) if tot>0 else np.nan,
                rate_Hz=float(np.mean(a[:,2])),spiking_fraction=float(np.mean(a[:,2]>0)),
                mean_ISI_ms=float(np.nanmean(a[:,3])) if np.isfinite(a[:,3]).any() else np.nan,
                min_x=float(np.min(a[:,4])),max_x=float(np.max(a[:,5])),
                min_z=float(np.min(a[:,6])),max_z=float(np.max(a[:,7])),nrep=nrep))
    return outs

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True)
    p.add_argument('--nrep',type=int,default=16);p.add_argument('--workers',type=int,default=4)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(SUPPORT);d['J_q75']=d.rheobase_J+0.75*(d.cell_id.map(JMAX)-d.rheobase_J)
    wt=d[d.cell_id.str.startswith('WT_')];sc=d[d.cell_id.str.startswith('SCA3_')]
    tasks=[]
    for wc in sorted(wt.cell_id.unique()):
        for sca in sorted(sc.cell_id.unique()):
            for _,w in wt[wt.cell_id==wc].iterrows():
                for _,s in sc[sc.cell_id==sca].iterrows():
                    tasks.append((len(tasks),w.to_dict(),s.to_dict()))
    assert len(tasks)==264
    rows=[];start=time.perf_counter()
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        futures=[pool.submit(process,t,a.nrep) for t in tasks]
        for k,fut in enumerate(as_completed(futures)):
            rows.extend(fut.result())
            if (k+1)%20==0 or k+1==len(tasks): print(f'PROGRESS {k+1}/264 elapsed={time.perf_counter()-start:.1f}s',flush=True)
            if (k+1)%40==0:pd.DataFrame(rows).to_csv(a.out/'checkpoint.csv',index=False)
    res=pd.DataFrame(rows).sort_values(['scenario_id','protocol','noise_scale','reference'])
    res.to_csv(a.out/'all264_directional_KL.csv',index=False)
    manifest=dict(n_scenarios=264,n_pairs=32,settings=[('paired_q75',1.0),('matched_WT_J',1.0),('no_drive',1.0),('paired_q75',0.5),('paired_q75',2.0)],
        same_start='per WT retained-fit 500ms no-input RK4 state used for both reference laws',
        fixed_J_choice='J equal to WT q75 in both endpoint laws; may lie outside SCA3 observed support',
        no_drive_choice='J=0 in both, tests intrinsic b,r,s only (kappa cancels)',
        nrep=a.nrep,dt_ms=DT,stim_ms=STIM_MS,
        fisher_convention='D_KL = 1/4 expectation integral deltaf.T D^-1 deltaf dt',
        support_sha256=hashlib.sha256(SUPPORT.read_bytes()).hexdigest(),elapsed_s=time.perf_counter()-start,
        status='ENDPOINT_PATH_KL_DIAGNOSTIC_NOT_THERMODYNAMIC_EPR')
    (a.out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    print(json.dumps(manifest,indent=2),flush=True)

if __name__=='__main__':main()
