from pathlib import Path
import argparse
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--stage', type=int, choices=range(5))
args = parser.parse_args()
root = Path(__file__).resolve().parent
for stage in range(5) if args.stage is None else [args.stage]:
    for mode in ['nav16', 'kv3', 'mix']:
        subprocess.run([sys.executable, str(root/f'purkinje_{mode}.py'),
                        '--stage', str(stage)], check=True)
print('Результаты:', root/'результаты')
