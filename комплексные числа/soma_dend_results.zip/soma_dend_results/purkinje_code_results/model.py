# Masoli et al. (2015), ModelDB 229585; упрощённая геометрия
from pathlib import Path
import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import sysconfig
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import neuron
from neuron import h

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'результаты'
STAGES = ['00_soma', '01_one_dendrite', '02_three_dendrites',
          '03_branching_1', '04_branching_2']
TITLES = ['Сома', 'Сома + 1 дендрит', 'Сома + 3 дендрита',
          'Сома + 9 дендритных секций', 'Сома + 21 дендритная секция']
VOLTAGES = np.arange(-100., 61., 10.)  # мВ
DT = .0025  # мс
RECORD_DT = .01  # мс
STOP = 300.  # мс
TEMPERATURE = 37.
ENA, EK = 60., -88.  # мВ
NA_SOMA, NA_PRIMARY, NA_BRANCH = .214, .016, 0.  # См/см²
K33_SOMA, K33_DEND = 0., .01  # См/см²
K34_SOMA, K34_DEND = .05, 0.  # См/см²
KEYS = ['Nav16_nA', 'Kv33_nA', 'Kv34_nA', 'total_nA', 'clamp_nA', 'cap_nA']


def load_channels():
    if all(hasattr(h, name) for name in ['Nav1_6', 'Kv3_3', 'Kv3_4']):
        return
    mods = sorted((ROOT/'mechanisms').glob('*.mod'))
    digest = hashlib.sha256(h.nrnversion().encode()+b''.join(p.read_bytes() for p in mods)).hexdigest()[:12]
    build = ROOT/'mechanisms_auto'/digest
    build.mkdir(parents=True, exist_ok=True)

    def libraries():
        return sorted(p for p in build.rglob('*') if p.name in
                      ['libnrnmech.so', 'libnrnmech.dylib', 'nrnmech.dll'])

    if not libraries():
        for path in mods:
            shutil.copy2(path, build/path.name)
        compiler = shutil.which('nrnivmodl')
        command = [compiler] if compiler else None
        for path in [Path(sysconfig.get_path('scripts'))/'nrnivmodl',
                     Path(neuron.__file__).resolve().parent.parent/'bin'/'nrnivmodl']:
            if command is None and path.is_file():
                command = [sys.executable, str(path)]
        if command is None:
            raise RuntimeError('Не найден nrnivmodl. Нужен NEURON с компилятором C/C++.')
        print('Сборка механизмов...', flush=True)
        env = os.environ.copy()
        if 'CXX' not in env and shutil.which('g++'):
            env['CXX'] = 'g++'
        if 'CC' not in env and shutil.which('gcc'):
            env['CC'] = 'gcc'
        result = subprocess.run(command, cwd=build, env=env, capture_output=True, text=True, errors='replace')
        if result.returncode or not libraries():
            (ROOT/'ошибка_сборки.txt').write_text(result.stdout+result.stderr, encoding='utf-8')
            raise RuntimeError('Ошибка сборки: см. ошибка_сборки.txt')
    h.nrn_load_dll(str(libraries()[0]))


def make_cell(stage, mode):
    soma = h.Section(name='soma')
    soma.L = soma.diam = 20  # мкм
    soma.nseg = 1
    sections = [soma]
    levels = [-1]
    parents = [-1]

    def add(parent, level):
        sec = h.Section(name=f'dend_{len(sections)-1:02d}')
        sec.L = 20  # мкм
        sec.diam = [2., 1.5, 1.2][level]  # мкм
        sec.nseg = 5
        sec.connect(sections[parent](1), 0)
        index = len(sections)
        sections.append(sec)
        levels.append(level)
        parents.append(parent)
        if level < max(0, stage-2):
            add(index, level+1)
            add(index, level+1)

    for _ in range(0 if stage == 0 else 1 if stage == 1 else 3):
        add(0, 0)
    rows = []
    for i, (sec, level, parent) in enumerate(zip(sections, levels, parents)):
        sec.Ra = 100  # Ом*см
        sec.cm = 1  # мкФ/см²
        sec.insert('Nav1_6')
        sec.insert('Kv3_3')
        sec.insert('Kv3_4')
        na = NA_SOMA if i == 0 else NA_PRIMARY if level == 0 else NA_BRANCH
        k33 = K33_SOMA if i == 0 else K33_DEND
        k34 = K34_SOMA if i == 0 else K34_DEND
        for seg in sec:
            seg.ena, seg.ek = ENA, EK
            seg.Nav1_6.gbar = na if mode in ['nav16', 'mix'] else 0
            seg.Kv3_3.gbar = k33 if mode in ['kv3', 'mix'] else 0
            seg.Kv3_3.gateCurrent = 0
            seg.Kv3_4.gkbar = k34 if mode in ['kv3', 'mix'] else 0
        rows.append(dict(name=sec.name(), parent=parent, level=level,
                         L_um=sec.L, diam_um=sec.diam, nseg=sec.nseg,
                         area_um2=sum(h.area(s.x, sec=sec) for s in sec),
                         gNa_S_cm2=sec(.5).Nav1_6.gbar,
                         gKv33_S_cm2=sec(.5).Kv3_3.gbar,
                         gKv34_S_cm2=sec(.5).Kv3_4.gkbar))
    return sections, rows


def simulate(voltage, stage, mode, dt=DT):
    h.dt = dt  # мс
    h.steps_per_ms = 1/dt
    sections, rows = make_cell(stage, mode)
    segments = [seg for sec in sections for seg in sec]
    area = np.array([h.area(seg.x, sec=seg.sec) for seg in segments])  # мкм²
    refs = [('V', lambda s: s._ref_v), ('Na', lambda s: s.Nav1_6._ref_ina),
            ('K33', lambda s: s.Kv3_3._ref_ik), ('K34', lambda s: s.Kv3_4._ref_ik),
            ('cap', lambda s: s._ref_i_cap)]
    records = {name: [h.Vector().record(get_ref(s), RECORD_DT) for s in segments]
               for name, get_ref in refs}
    clamp = h.SEClamp(sections[0](.5))
    clamp.rs = .0001  # МОм
    clamp.dur1, clamp.dur2 = 100, STOP  # мс
    clamp.amp1, clamp.amp2 = -100, float(voltage)  # мВ
    time = h.Vector().record(h._ref_t, RECORD_DT)
    current = h.Vector().record(clamp._ref_i, RECORD_DT)
    h.finitialize(-100)
    h.continuerun(STOP)
    d = dict(time_ms=np.array(time), clamp_nA=np.array(current),
             voltage_segments_mV=np.array([np.array(v) for v in records['V']]),
             area_segments_um2=area,
             segment_section=np.array([i for i, sec in enumerate(sections) for s in sec]),
             segment_x=np.array([s.x for s in segments]))
    d['voltage_mV'] = d['voltage_segments_mV'][0]
    for name, key in [('Na', 'Nav16_nA'), ('K33', 'Kv33_nA'),
                      ('K34', 'Kv34_nA'), ('cap', 'cap_nA')]:
        values = np.array([np.array(v) for v in records[name]])
        d[key] = np.sum(values*area[:, None]*.01, axis=0)
    d['total_nA'] = d['Nav16_nA']+d['Kv33_nA']+d['Kv34_nA']
    for sec in reversed(sections):
        h.delete_section(sec=sec)
    return d, rows


def table(path, columns):
    np.savetxt(path, np.column_stack(list(columns.values())), delimiter=',',
               header=','.join(columns), comments='')


def mappings(current):
    z = VOLTAGES/100.+1j*current/10.
    inverse = np.full(z.shape, complex(np.nan, np.nan))
    valid = abs(z) >= 1e-4
    inverse[valid] = 1/z[valid]
    return dict(z=z, z2=z*z, inverse=inverse, exp=np.exp(z))


def plot_iv(curves, trace, title, path):
    fig, axes = plt.subplots(2, 3, figsize=(13, 8), layout='constrained')
    axes = axes.ravel()
    for label, current in curves.items():
        line, = axes[0].plot(VOLTAGES, current, 'o-', ms=3, label=label)
        for ax, values in zip(axes[1:5], mappings(current).values()):
            ax.plot(values.real, values.imag, 'o-', ms=3, color=line.get_color())
    axes[0].set(title='ВАХ', xlabel='V команды, мВ', ylabel='I, нА')
    axes[0].legend(fontsize=8)
    for ax, name in zip(axes[1:5], ['z', 'z²', '1/z', 'exp(z)']):
        ax.set(title=name, xlabel='Re', ylabel='Im')
        ax.set_aspect('equal', adjustable='datalim')
    t = trace['time_ms']-100
    use = (t >= -1) & (t <= 35)
    for key, label in [('total_nA', 'Ионный ток'), ('clamp_nA', 'Электрод')]:
        axes[5].plot(t[use], trace[key][use], label=label)
    axes[5].set(title='Ток при −40 мВ', xlabel='Время от ступени, мс', ylabel='I, нА')
    axes[5].legend(fontsize=8)
    for ax in axes:
        ax.grid(alpha=.25)
    fig.suptitle(title)
    fig.savefig(path, dpi=180)
    plt.close(fig)


def run(stage, mode):
    folder = OUT/STAGES[stage]
    folder.mkdir(parents=True, exist_ok=True)
    times = [.5, 8., 100.] if mode == 'mix' else [None]
    selected = {t: [] for t in times}
    trace = None
    voltage_rows = []
    for n, voltage in enumerate(VOLTAGES):
        print(f'{STAGES[stage]}, {mode}: {voltage:g} мВ', flush=True)
        d, rows = simulate(voltage, stage, mode)
        t = d['time_ms']
        for time in times:
            if mode == 'nav16':
                indices = np.flatnonzero((t >= 100.03) & (t <= 130))
                ix = indices[np.argmax(abs(d['Nav16_nA'][indices]))]
                values = [d[k][ix] for k in KEYS]
            elif mode == 'kv3':
                use = (t >= 295) & (t <= 299)
                values = [np.mean(d[k][use]) for k in KEYS]
            else:
                ix = np.argmin(abs(t-(100+time)))
                values = [d[k][ix] for k in KEYS]
            selected[time].append(values)
        if mode == 'mix':
            for time in times:
                ix = np.argmin(abs(t-(100+time)))
                v = d['voltage_segments_mV'][:, ix]
                voltage_rows.append([voltage, time, v[0], v.min(), v.max(),
                                     np.max(abs(v-v[0])), v[0]-voltage])
        if voltage == -40:
            trace = d
    for time, values in selected.items():
        suffix = '' if time is None else f'_{time:g}ms'
        a = np.array(values)
        columns = dict(V_command_mV=VOLTAGES)
        columns.update(dict(zip(KEYS, a.T)))
        for name, z in mappings(a[:, 3]).items():
            columns[name+'_Re'], columns[name+'_Im'] = z.real, z.imag
        table(folder/f'{mode}_iv_complex{suffix}.csv', columns)
        curves = dict(zip(['Nav1.6', 'Kv3.3', 'Kv3.4', 'Сумма'], a[:, :4].T))
        if mode == 'nav16':
            curves = {'Nav1.6': a[:, 0]}
        elif mode == 'kv3':
            curves = {k: v for k, v in curves.items() if k != 'Nav1.6'}
        plot_iv(curves, trace, f'{TITLES[stage]}, {mode}'+('' if time is None else f', {time:g} мс'),
                folder/f'{mode}_complex{suffix}.png')
    if mode == 'mix':
        names = ['V_command_mV', 'time_after_step_ms', 'V_soma_mV',
                 'V_min_mV', 'V_max_mV', 'max_segment_soma_difference_mV',
                 'V_soma_minus_command_mV']
        table(folder/'voltage.csv', dict(zip(names, np.array(voltage_rows).T)))
    print('Сохранено:', folder, flush=True)


def main(mode):
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', type=int, choices=range(5))
    args = parser.parse_args()
    load_channels()
    h.load_file('stdrun.hoc')
    h.cvode_active(0)
    h.secondorder = 0
    h.celsius = TEMPERATURE
    for stage in range(5) if args.stage is None else [args.stage]:
        run(stage, mode)
